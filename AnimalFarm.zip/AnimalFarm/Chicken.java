package AnimalFarm;

public class Chicken {

    private String name;
    private int age;


    public Chicken(String name, int age) {
        this.setName(name);
        this.setAge(age);
    }

    public void setName(String name) {
        if (name.length() <= 1) {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
        this.name = name;
    }

    public void setAge(int age) {
        if (age >= 0 )  {
            this.age = age;
        } else if (age >= 7) {
            this.age = age;
        } else if (age >= 8 && age <= 15) {
            this.age = age;
        } else {
            throw new IllegalArgumentException("Age should be between o and 15");
        }

    }

    public double productPerDay() {
        if (age > 0 && age <=5) {
            return 2;
        } else if (age <= 11) {
            return 1;
        } else if (age >11 && age <=15) {
            return 0.75;
        }
        return 0;
    }

    private double calculatedProductPerDay() {
        return productPerDay();
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
