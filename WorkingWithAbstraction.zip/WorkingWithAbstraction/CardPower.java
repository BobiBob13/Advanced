package WorkingWithAbstraction;

public enum CardPower {

}
