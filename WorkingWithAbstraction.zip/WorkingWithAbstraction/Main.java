package WorkingWithAbstraction;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Card Ranks:");
        for (Card suit : Card.values()) {
            System.out.printf("Ordinal value: %d; Name value: %s%n",suit.getValue(),suit.toString());
        }
        }
    }
